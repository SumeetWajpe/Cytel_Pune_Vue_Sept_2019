<template>
<div>
    <div class="jumbotron">
        <h1> All Posts </h1>
    </div>
    <ul>
        <li v-for="post in allposts" :key="post.id">
          <!-- <router-link to="/postdetails/10">  {{post.title}}  </router-link> -->
          <router-link :to="{ name: 'postsdetails', params: { id: post.id }}">  {{post.title}}  </router-link>

        </li>
    </ul>
    </div>
</template>

<script>
import axios from 'axios';


    export default {
        data(){
                return {
                    allposts:[]
                }
        },
        mounted(){
            axios.get('https://jsonplaceholder.typicode.com/posts').then(
                (response)=>{
                    this.allposts = response.data;
                }
            )
        }
    }
</script>

<style scoped>

</style>