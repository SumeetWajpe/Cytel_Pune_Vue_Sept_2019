<template>
    <div>
            <h1>Post Details for {{id}} </h1>
    </div>
</template>

<script>
    export default {
        name:'PostDetails',
        data(){
            return {
                id: this.$route.params.id
            }
        }
    }
</script>

<style scoped>

</style>