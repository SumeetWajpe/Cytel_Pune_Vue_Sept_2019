<template>
<div :class="classesToBeApplied">
    <!-- <button  class="btn btn-danger" 
    @click="DeleteProduct(productdetails.id)">
        <span class="glyphicon glyphicon-trash"></span>
    </button> -->
    <!-- Default Slot -->
    <slot>
    </slot>
    <!-- NamedSlot -->
   <!-- <slot name="header">
    </slot> -->
<!-- Scoped Slot -->
    <!-- <slot name="header" v-bind:productdetails="productdetails">
    </slot>      -->
    <h2>{{productdetails.title | capitalize }} </h2>
    <br/>
    Add to Cart : <input type="checkbox" 
    v-model="isSelected" :disabled="!productdetails.quantity" /> <br/>
    
    <img :src="productdetails.ImageUrl" 
    height="200px" width="200px"
    :style="productdetails.quantity ? '' : {opacity:0.3}" 
    /><br />

Is the product Free ? : <input type="checkbox" v-model="isFree" />
<p v-if="!isFree">
    <b>Price : </b>{{productdetails.price | currency(`₹`)  }}
</p>
<p v-else>
   <strong style="color:green"> This product is FREE ! FREE ! FREE !</strong>
</p>


    <b>Rating : </b>{{productdetails.rating }} <br />
    <b>Quantity : </b><strong 
    :style="productdetails.quantity ? '' : {color:'red'}">{{productdetails.quantity | outofstock('items')}}</strong><br />

    <button class="btn btn-primary">
        <span class="glyphicon glyphicon-thumbs-up">
        </span>
        {{productdetails.likes}}
    </button>
</div>
</template>

<script>
export default {
    name: 'Product',
    props: {
        productdetails: Object
    },
    data() {
        return {
            isSelected:false,
            isFree:false
        }
    },
    methods:{
            DeleteProduct(theId){
                // emit the event
                this.$emit('delete-a-product',theId)
            }
    },
    computed:{
        classesToBeApplied(){
            return {
                productStyle:true,
                selected:this.isSelected               
            }
        }
    },
    filters:{
        capitalize(val){
            return val.toUpperCase();
        },
        outofstock(val,args){
            switch(val){
                case 0:
                    return 'OUT OF STOCK';
                case 1:
                    return  val + " " + args.substring(0,args.length - 1)
                default:
                    return val + " " + args;
            }
        }
    }
}
</script>

<style scoped>
.productStyle {
    border: 2px solid lightgray;
    border-radius: 10px;
    margin: 10px;
    padding: 10px;
    box-shadow: 10px 10px 20px;
}
.selected{
    background-color: lightblue; 
}
</style>
