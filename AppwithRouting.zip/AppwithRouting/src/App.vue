<template>
   <div id="app" class="container">    
    <!-- <ShoppingCart/> -->
    <!-- <Posts/> -->
    <!-- <a href="/">Home </a> | 
    <a href="/posts">Posts </a> -->
  

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
          <router-link class="navbar-brand" to="/">Online Shopping </router-link>
    </div>
    <ul class="nav navbar-nav">
      <li>    <router-link to="/">Home </router-link></li>
      <li><router-link to="/posts">Posts </router-link> </li>
    </ul>
  </div>
</nav>

    <router-view></router-view>
  </div>
</template>

<script>
import ShoppingCart from './components/shoppingcart.vue';
import Posts from './components/posts';

export default {
  name: 'app',
  components: {
    ShoppingCart,
    Posts
  }
}

</script>

<style>

</style>
