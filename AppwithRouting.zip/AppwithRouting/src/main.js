import Vue from 'vue'
import App from './App.vue';
import VueRouter from 'vue-router';
import ShoppingCart from './components/shoppingcart.vue';
import Posts from './components/posts.vue';
import PostDetails from './components/postdetails.vue';

Vue.config.productionTip = false
Vue.use(VueRouter);

const routes = [
  {path:'',component:ShoppingCart},
  {path:'/posts',component:Posts},
  {path:'/postdetails/:id',component:PostDetails, name:'postsdetails'},

];

var router = new VueRouter({
  routes,
  mode:'history'
}); 

Vue.filter('currency',function(val,args){
    return `${val}${args}`;
});

new Vue({
  render: h => h(App),
  router,
}).$mount('#app')
