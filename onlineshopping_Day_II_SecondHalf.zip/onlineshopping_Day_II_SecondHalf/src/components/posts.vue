<template>
<div>
    <div class="jumbotron">
        <h1> All Posts </h1>
    </div>
    <ul>
        <li v-for="post in allposts" :key="post.id">{{post.title}}</li>
    </ul>
    </div>
</template>

<script>
import axios from 'axios';


    export default {
        data(){
                return {
                    allposts:[]
                }
        },
        mounted(){
            axios.get('https://jsonplaceholder.typicode.com/posts').then(
                (response)=>{
                    this.allposts = response.data;
                }
            )
        }
    }
</script>

<style scoped>

</style>