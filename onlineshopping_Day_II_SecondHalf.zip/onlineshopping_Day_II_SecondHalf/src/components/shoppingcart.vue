<template>
<div>
    <div class="jumbotron">
      <h1>  Online Shopping </h1>
    </div>
    <div class="row">
        <div class="col-md-4" v-for="product in products" 
        :key="product.id">
            <!-- <Product :productdetails="product"
            @delete-a-product="DeleteAProduct($event)" /> -->
            <Product :productdetails="product">
                <button class="btn btn-success" 
                @click="DeleteAProduct(product.id)">
                    Delete
                </button>
                <!-- <template v-slot:header>
                    <h2> {{product.title}}</h2>
                </template> -->
                 <template v-slot:header="slotProps" >
                    <h2> {{slotProps.productdetails.title}}</h2>
                </template>
                <!-- <button class="btn btn-success">
                    Add
                </button> -->
            </Product>
        </div>
    </div>
</div>
</template>

<script>
import Product from './product.vue';
import axios from 'axios';

export default {
    name: 'ShoppingCart',
    components: {
        Product
    },
    data() {
        return {
            products: []
        }

    },
    mounted(){
         axios.get('https://api.myjson.com/bins/wxhl5').then((response)=> this.products = response.data)
    }
    ,methods:{
        DeleteAProduct(theid){
            // splice
            let theIndex = this.products.findIndex(p=> p.id == theid);
            this.products.splice(theIndex,1);

           
        }
    }
}
</script>

<style scoped>

</style>
