<template>
   <div id="app" class="container">    
    <ShoppingCart/>
    <!-- <Posts/> -->
  </div>
</template>

<script>
import ShoppingCart from './components/shoppingcart.vue';
import Posts from './components/posts';

export default {
  name: 'app',
  components: {
    ShoppingCart,
    Posts
  }
}

</script>

<style>

</style>
