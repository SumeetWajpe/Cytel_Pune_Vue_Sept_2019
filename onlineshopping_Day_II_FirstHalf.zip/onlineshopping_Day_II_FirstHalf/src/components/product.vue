<template>
<div class="productStyle">
    <h2>{{productdetails.title }}</h2>
    
    <img :src="productdetails.ImageUrl" height="200px" width="200px" /><br />

    <b>Price : </b>{{productdetails.price }} <br />

    <b>Rating : </b>{{productdetails.rating }} <br />
    <b>Quantity : </b>{{productdetails.quantity }}<br />

    <button class="btn btn-primary">
        <span class="glyphicon glyphicon-thumbs-up">
        </span>
        {{productdetails.likes}}
    </button>
</div>
</template>

<script>
export default {
    name: 'Product',
    props: {
        productdetails: Object
    },
    data() {

    }
}
</script>

<style scoped>
.productStyle {
    border: 2px solid lightgray;
    border-radius: 10px;
    margin: 10px;
    padding: 10px;
    box-shadow: 10px 10px 20px;
}
</style>
