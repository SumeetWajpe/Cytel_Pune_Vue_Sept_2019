<template>
   <div id="app" class="container">    
    <ShoppingCart/>
  </div>
</template>

<script>
import ShoppingCart from './components/shoppingcart.vue';


export default {
  name: 'app',
  components: {
    ShoppingCart
  }
}

</script>

<style>

</style>
